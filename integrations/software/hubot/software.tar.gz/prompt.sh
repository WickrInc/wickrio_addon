#!/bin/bash

SOURCE="$PWD"
SETTINGS_FILE="$SOURCE/tokens.txt"
SETTINGS=`cat "$SETTINGS_FILE"`
  for i in ${SETTINGS[@]}
do
echo $i
read  input
if [[ ! -z "$input" ]]; then
   echo ${i}=${input} >> input.txt
fi
done
