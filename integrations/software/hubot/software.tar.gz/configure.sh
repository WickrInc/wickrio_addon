#!/bin/sh

node integrationChecker
