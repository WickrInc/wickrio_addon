// Description
//  A hubot adapter for Wickr.
//
// Configuration:
//   WICKRIO_SERVER - Server on which hubot is deployed on.
//   WICKRIO_wickrio_auth_token - Wickr's API authorization token for the header of a 'send message' POST request.
//   HUBOT_URL_ENDPOINT - port on which wickr bot is responding to after receiveing a message.
//
// Authors:
// Aaron <amishiyev@wickr.com>
// Pak <pchu@wickr.com>

'use strict';

const Robot = require('../../../src/robot');
const Adapter = require('../../../src/adapter');
const Message = require('../../../src/message');
const User = require('../../../src/user');

const TextMessage = Message.TextMessage;


class Wickr extends Adapter {

  constructor() {
    super(...arguments);
    this.robot.logger.info("Constructor");
  }

  send(envelope, ...strings) {
    let vgroupid = envelope.room;
    let user;
    if(envelope.user === undefined || envelope.user === null) {
      user = envelope;
    } else {
      user = envelope.user.name;
    }

    let data;
    let JSONData;
    let wickrio_server = process.env.WICKRIO_SERVER;
    let wickrio_auth_token = process.env.WICKRIO_AUTH_TOKEN;
    //Check if vgroupid exists, if it does not exist send directly to user
    if (vgroupid) {

      for (let str of Array.from(strings)) {
        data = {
          "message": str,
          "vgroupid": vgroupid
        }
        JSONData = JSON.stringify(data);
        //POST to Wickr chat
        this.robot.http(wickrio_server + '/messages')
          .header('Content-Type', 'application/json')
          .header('Authorization', 'Basic ' + wickrio_auth_token)
          .post(JSONData)(function(err, res, body) {
            if (err) {
              console.log(err);
            }
          });
      }
    } else if (user) {
      for (let str of Array.from(strings)) {
        data = {
          "message": str,
          "users": [{
            "name": user
          }]
        }
        JSONData = JSON.stringify(data);
        this.robot.http(wickrio_server + '/messages')
          .header('Content-Type', 'application/json')
          .header('Authorization', 'Basic ' + wickrio_auth_token)
          .post(JSONData)(function(err, res, body) {
            if (err) {
              console.log(err);
            }
          });
      }
    }
  }

  reply(envelope, ...strings) {
    return Array.from(strings).map((str) =>
      this.send(envelope, `${str}`));
  }


  command(command, ...strings) {
    return this.send(command, strings);
  }

  run() {
    this.robot.logger.info("Run");
    this.emit("connected");
    this.hubot_url_endpoint = process.env.HUBOT_URL_ENDPOINT;
    this.robot.router.post(this.hubot_url_endpoint, (req, res) => {
      let data;
      let vgroupid = req.body.vgroupid;
      let message;
      let user1;
      let user_name = req.body.sender;
      if(vgroupid) {
        data = req.body.message;
        user1 = new User(1001, {
          name: '',
          room: vgroupid
        });
        message = new TextMessage(user1, data, '');
        this.robot.receive(message);
        this.robot.logger.info("Message sent to hubot brain.");
        res.send('Successful');
      } else {
        data = req.body.message;
        user1 = new User(1001, {
          name: user_name,
          room: ''
        });
        message = new TextMessage(user1, data, '');
        this.robot.receive(message);
        this.robot.logger.info("Message sent to hubot brain.");
        res.send('Successful');
      }

    });
  }
}

exports.use = robot => new Wickr(robot);
