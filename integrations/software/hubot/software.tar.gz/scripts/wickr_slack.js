// Description
//   A hubot script that allows users to send messages to Slack users from Wickr.
//
// Configuration:
//   SLACK_TOKEN - Sender's private slack token
//   WICKRIO_SERVER -
//   WICKRIO_AUTH_TOKEN -
//
// Commands:
//   hubot slack SLACK_USER message ACTUAL_MESSAGE
//
// Authors:
//  Aaron <amishiyev@wickr.com>
//  Pak <pchu@wickr.com>

var axios = require('axios');
var request = require('request');
const User = require('../src/user');

module.exports = (robot) => {
  var wickrio_server = process.env.WICKRIO_SERVER;
  var wickrio_auth_token = process.env.WICKRIO_AUTH_TOKEN;
  var slack_client_id = process.env.SLACK_CLIENT_ID;
  var slack_client_secret = process.env.SLACK_CLIENT_SECRET;
  var slack_redirect_uri = process.env.SLACK_REDIRECT_URI;

  //Wickr To Slack

  //command to trigger the script
  robot.respond(/slack (.*) message (.*)/i, function(res) {
    var fullCmd = res.match[0];
    fullCmd = fullCmd.split('message');
    var slackUser = fullCmd[0].split('/slack');
    slackUser = slackUser[1].toLowerCase().replace(/^[ ]+|[ ]+$/g, '');
    var slackMsg = fullCmd[1].replace(/^[ ]+|[ ]+$/g, '');
    let resScope = res;
    var userID = '';
    var wickrID = res.message.user.id;
    //console.log("wickrID#1:",wickrID);
    //var wickrName = res.message.user.name;
    //console.log("wickrName:" , wickrName);
    //Check if user logged in to Slack already
    var user = robot.brain.userForName(wickrID);
    if (user.slack_access_token == null) {
      robot.brain.data.users[wickrID] = new User(wickrID, {
        name: wickrID,
        slackUser: slackUser,
        slackMsg: slackMsg
      });
      resScope.reply('Please login to your Slack account to continue: ' + "https://slack.com/oauth/authorize?client_id=" + slack_client_id + '&scope=users.profile:read,users:read,chat:write:user&redirect_uri=' + slack_redirect_uri + '&state=' + wickrID);
    } else {
      //console.log(user);
      sendMessage(slackUser, slackMsg);
    }

    robot.router.get('/authorize', (req, res, next) => {
      wickrID = req.query.state;
      //console.log("wickrID#2:",wickrID);
      //console.log("req: ", req.query);
      res.send("Thanks for signing into Slack using Wickr. Enjoy!");
      return new Promise((resolve, reject) => {
        resolve(req);
      }).then(req => {
        if (req.error === "access_denied") {
          resScope.reply("Wickr is not able to send Slack messages without your permission.");
          console.log("User denied access to his Slack account.")
          return;
        }
        return new Promise((resolve, reject) => {
          const code = req.query.code;
          resolve(code);
        }).then(code => {
          return new Promise((resolve, reject) => {
            robot.http('https://slack.com/api/oauth.access?' + "client_id=" + slack_client_id + "&client_secret=" + slack_client_secret + "&code=" + code + "&redirect_uri=" + slack_redirect_uri).header('Content-Type', 'application/x-www-form-urlencoded').get()(function(error, response, body) {
              if (error) {
                console.log("error: " + error);
              }
              let data = JSON.parse(body);
              //console.log("oauth data:", data);
              resolve(data);
            });
          }).then(result => {
            return new Promise((resolve, reject) => {
              //robot.brain.set('slack_access_token', result.access_token); keep secure
              //console.log(wickrID, "result.access_token:", result.access_token);
              robot.http('https://slack.com/api/users.profile.get?' + 'token=' + result.access_token).header('Content-Type', 'application/x-www-form-urlencoded').get()(function(error, response, body) {
                if (error) {
                  console.log("error: " + error);
                }
                let data = JSON.stringify(body);
                //console.log("data: " , data);
                //var slack_user_email = data.profile.email;
                //var matchedUser = robot.brain.userForName(wickrID);
                //console.log("matchedUser:", matchedUser);
                user = robot.brain.userForName(wickrID);
                //console.log("robot.brain.data.users[wickrID]:", robot.brain.data.users[wickrID]);
                slackUser = robot.brain.data.users[wickrID].slackUser;
                slackMsg = robot.brain.data.users[wickrID].slackMsg;
                robot.brain.data.users[wickrID] = new User(wickrID, {
                  slack_access_token: result.access_token,
                  name: wickrID,
                  slackUser: slackUser,
                  slackMsg: slackMsg
                });
                resolve(result.access_token);
              });
            }).then(result => {
              //console.log("105\nresScope:",resScope);
              //console.log("slackUser106:", slackUser);

              robot.brain.data.users[wickrID] = new User(wickrID, {
                slack_access_token: result,
                name: wickrID
              });
              console.log(robot.brain.users());
              //console.log("slackUser113:", slackUser);
              sendMessage(slackUser, slackMsg);
            }).catch(err => {
              console.log(err);
            });
          }).catch(err => {
            console.log(err);
          });
        }).catch(err => {
          console.log(err);
        });
      }).catch(err => {
        console.log(err);
      });
    });

    function sendMessage(slackUser, slackMsg) {
      //making http request to find the specified user's ID from list of all users existing in the sender's workspace
      var access_token = robot.brain.data.users[wickrID].slack_access_token;
      console.log("slackUser133:", slackUser);
      robot.http("https://slack.com/api/users.list").header('Content-Type', 'application/json').header('Authorization', 'Bearer ' + access_token).post()(function(err, res, body) {
        return new Promise((resolve, reject) => {
          if (err) {
            reject(err);
            return;
          }
          let list = JSON.parse(body);
          //console.log("list: ", list);
          for (var x = 0; x < list.members.length; x++) {
            if (list.members[x].name === slackUser) {
              userID = list.members[x].id;
              resolve(userID);
              break;
            }
          }
          if (userID === '') {
            resScope.reply("Error: User Not Found."); /////////replace with post request
          }
        }).then(result => {
          userID = result;
          slackMsg = "Non-secure message sent using Wickr: " + slackMsg;
          let data = {
            "channel": userID,
            "text": slackMsg,
            "username": slackUser,
            "as_user": "true"
          }
          JSONData = JSON.stringify(data);
          //http request to post the message in the slack Chat/DM
          robot.http("https://slack.com/api/chat.postMessage").header('Content-Type', 'application/json; charset=UTF-8').header('Authorization', 'Bearer ' + access_token).post(JSONData)(function(err, res, body) {
            return new Promise((resolve, reject) => {
              let response = JSON.parse(body);
              if (err) {
                console.log(err);
              } else if (response.ok === false) {
                message = "Error: cannot send message: " + response.error;
              } else {
                message = "Non-secure message sent to Slack user " + slackUser;
              }
              var msgData = {
                "message": message,
                "users": [
                  {
                    "name": wickrID
                  }
                ]
              }
              resolve(msgData);
            }).then(result => {
              JSONData = JSON.stringify(result);
              robot.http(wickrio_server + '/Messages').header('Content-Type', 'application/json').header('Authorization', 'Basic ' + wickrio_auth_token).post(JSONData)(function(err, res, body) {
                if (err) {
                  console.log(err);
                }
              });
            }).catch(err => {
              console.log(err);
            });
          });
        }).catch(error => {
          console.log(error);
        })
      })
    }
  });

  //Slack To Wickr

  //listening to the incoming post request from Slack
  robot.router.post("/slack", (req, res) => {
    //res only exists outside the robot.http block
    var outsideRes = res;
    //the incoming body object
    let messageString = req.body.text;
    //splitting the string into array
    let arrayString = messageString.split(" ");
    //get the first email from the array
    let email = arrayString[1];
    //get the message position in the messageString/req.body/text
    let messagePosition = messageString.indexOf("message");
    //slice the message out from the string
    let message = messageString.slice(messagePosition + 8);
    //get the user name
    let userName = req.body.user_name;

    //parsing the message
    message = "Non-secure message from Slack user named " + userName + ": " + message;
    data = {
      "message": message,
      "users": [
        {
          "name": email
        }
      ]
    }
    //stringify the data before making http request
    JSONData = JSON.stringify(data);
    //hubot making http request to hubot that is living on AWS ubuntu.
    robot.http(wickrio_server + '/Messages').header('Content-Type', 'application/json').header('Authorization', 'Basic ' + wickrio_auth_token).post(JSONData)(function(err, res, body) {
      if (err) {
        outsideRes.send('Error: ' + err);
      } else if (body) {
        outsideRes.send(body);
      } else {
        outsideRes.send('Message sent to Wickr user ' + email);
      }
    });
  });

  //Room creation request in Wickr from Slack
  robot.router.post("/createroom", (req, res) => {
    var outsideRes = res;
    var index = req.body.text.indexOf("with");
    var roomName = req.body.text.slice(0, index - 1);
    var users = req.body.text.slice(index + 4);
    var arr = [];

    users = users.split(',');
    for (var i = 0; i < users.length; i++) {
      arr.push(users[i].trim(""));
    }

    var membersArr = [];
    for (var i = 0; i < arr.length; i++) {
      var temp = {};
      temp['name'] = arr[i];
      membersArr.push(temp);
    }

    let data = {
      "room": {
        "title": roomName,
        "description": "Slack-created room by: " + membersArr[0].name,
        "ttl": 0,
        "members": membersArr,
        "masters": [
          {
            "name": membersArr[0].name
          }
        ]
      }
    }
    const options = {
      headers: {
        'Authorization': "Basic " + wickrio_auth_token,
        'Content-Type': 'application/json'
      }
    };

    function createRoom(roomData, auth) {
      return axios.post(wickrio_server + '/Rooms', roomData, auth).then(function(parsedData) {
        outsideRes.send('Successful Room creation in Wickr');
        return parsedData.data.vgroupid;
      }).then(function(result) {

        data = {
          "message": "Enjoy your secured room, and have a nice day! Wickrbot OUT!",
          "vgroupid": result
        }

        JSONData = JSON.stringify(data);
        robot.http(wickrio_server + "/Messages").header('Content-Type', 'application/json').header('Authorization', "Basic " + wickrio_auth_token).post(JSONData)(function(err, res, body) {
          if (err) {
            console.log(err);
            outsideRes.send('Error: ' + err);
            return;
          }
        });
        return result;
      }).then(function(result) {
        const options = {
          url: wickrio_server + '/Rooms/' + result + '?reason=leave',
          method: 'DELETE',
          headers: {
            'Authorization': 'Basic ' + wickrio_auth_token,
            'Content-Type': 'application/json'
          }
        };

        setTimeout(function() {
          request(options, function(err, res, body) {
            if (err) {
              console.log(err);
              outsideRes.send('Error: ' + err);
              return;
            }
          })
        }, 2000)
      }).catch(function(errData) {
        console.log('Err ', errData);
        outsideRes.send('Err', errData);
        return errData
      });
    }
    createRoom(data, options);
  });
}
