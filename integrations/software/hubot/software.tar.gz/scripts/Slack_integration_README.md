# Initial Setup for a Wickr Integration in Slack done by the Admin:
1. Go on https://api.slack.com/apps --> login to your teams account
2. Go to "Your Apps" on the upper right corner of the page and choose "Create New App"
3. Inside the App choose "Add features and functionality" -> "Permissions"
4. "Add a new Redirect URL": put in the bot's public server address and port + '/authorize'
    Example: 'https://ubuntu.server.com:8090/authorize'
5. Scroll down to "Scopes" and select the following Permission Scopes:
OTHER
-Add a bot user (bot)
-Add commands to Wickr (commands)
CHAT
-Send messages as user (chat:write:user)
TEAM
-Access information about your workspace (team:read)
USERS
-Access your workspace’s profile information (users:read)
-View email addresses of people on this workspace (users:read.email)

6. Go back to "Basic Information" under the "Settings" menu on the left
7. Go to "Add features and functionality" -> "Slash Commands"
8. Create two new Commands:
   I.
   Command: /w
   Request URL: put in the bot's public server address and port + '/slack'
       Example: 'https://ubuntu.server.com:8090/slack'
   Short Description: Send a message to a Wickr user
   Usage Hint: send USER.EMAIL message ACTUAL_MESSAGE

   II.
   Command: /createroom
   Request URL: put in the bot's public server address and port + '/createroom'
       Example: 'https://ubuntu.server.com:8090/createroom'
   Short Description: Create a secure Wickr room
   Usage Hint: ROOMNAME with USER.EMAIL1, USER.EMAIL2, USER.EMAIL3

9. Now Go back to "Basic Information" under the "Settings" menu on the left
10. Go to "Add features and functionality" -> "Bots"
11. Click "Add a Bot User" and Enter the required information, then save by clicking "Add Bot User"
12. Choose "Install your app to your workspace" and click "Install App to Workspace"

Note: Slack_Client_ID and Slack_Client_SECRET, which are required to be set as environment variables during the Installation/configuration of the bot, are located on the "Basic Information" page under "App Credentials".

# Usage:
Slack to Wickr:
From anywhere in your slack team's workspace with the App you created during the Initial setup already installed
you can use the following commands:

1. /w send USER.EMAIL message ACTUAL_MESSAGE
Description: Send a non-secure message to a Wickr user

2. /createroom ROOMNAME with USER.EMAIL1, USER.EMAIL2, USER.EMAIL3
Description: Create a secure Wickr room

Wickr to Slack:
From your Wickr Pro App where you have a bot with a slack Integration already installed
you can use the following commands:
1. /slack USER.HANDLE message ACTUAL_MESSAGE
Description: Send a non-secure message to a Slack user
Note: First time each user sends a message, the bot will prompt him to login to his Slack account
and give the bot Permission to access his account through the Slack API.
