// Description
//   A hubot script that allows users to get ride information from Uber using Wickr.
//
// Commands:
//   hubot uber price <location> to <destination> - Cost and Duration of ride from <location> to <destination>
//   hubot uber time - Time an Uber car will take to get to your current location
//
// Authors:
//   Pak <pchu@wickr.com>
//   Aaron <amishiyev@wickr.com>

var request = require("request");


module.exports = (robot) => {
  let server_token = process.env.SERVER_TOKEN;

  robot.respond(/uber price (.*) to (.*)/i, function(res) {
    let from = res.match[1].replace(/ /g, "+");
    let to = res.match[2].replace(/ /g, "+");
    let resScope = res;

    robot.http('https://maps.googleapis.com/maps/api/geocode/json?address=' + from + '&key=AIzaSyBQULp7Y6W9x0Wnq_dBRQsLnY7L52dJ81U').post()(function(err, response, body) {
      let data = JSON.parse(body);
      let latFrom = data.results[0].geometry.location.lat;
      let lngFrom = data.results[0].geometry.location.lng;

      robot.http('https://maps.googleapis.com/maps/api/geocode/json?address=' + to + '&key=AIzaSyBQULp7Y6W9x0Wnq_dBRQsLnY7L52dJ81U').post()(function(err, response, body) {
        let data = JSON.parse(body);
        let latTo = data.results[0].geometry.location.lat;
        let lngTo = data.results[0].geometry.location.lng;

        robot.http('https://api.uber.com/v1.2/estimates/price?start_latitude=' + latFrom + '&start_longitude=' + lngFrom + '&end_latitude=' + latTo + '&end_longitude=' + lngTo)
          .header('Authorization', 'Token ' + server_token)
          .header('Content-Type', 'application/json')
          .get()(function(err, response, body) {
            let data = JSON.parse(body);
            for (x in data.prices) {
              resScope.reply('Product: ' + data.prices[x].localized_display_name + ', Price Estimate: ' + data.prices[x].estimate +
                ', Duration: ' + (data.prices[x].duration) / 60 + ' minutes.');
            }
          });
      });
    });
  });

  robot.respond(/uber time/i, function(res) {
    let resScope = res;
    robot.http('https://www.googleapis.com/geolocation/v1/geolocate?key=AIzaSyDlGzMZRkXx2c51zOcc6xgX3OXLEpK0jHo').post()(function(err, response, body) {
      let data = JSON.parse(body);
      let latFrom = data.location.lat;
      let lngFrom = data.location.lng;
      robot.http('https://api.uber.com/v1.2/estimates/time?start_latitude=' + latFrom + '&start_longitude=' + lngFrom)
        .header('Authorization', 'Token ' + server_token)
        .header('Content-Type', 'application/json')
        .get()(function(err, response, body) {
          let data = JSON.parse(body);
          for (x in data.times) {
            resScope.reply(
              'Product: ' + data.times[x].localized_display_name + ', Time Estimate: ' + (data.times[x].estimate) / 60 + ' minutes.');
          }
        });
    });
  });
}
