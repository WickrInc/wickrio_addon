// Description
//  A hubot script that allows users to send messages to Salesforce Chatter users from Wickr and vice versa.
//
// Commands:
//  hubot chatter USER_NAME message ACTUAL_MESSAGE
//
// Configuration:
//  CHATTER_CLIENT_ID -
//  CHATTER_CLIENT_SECRET -
//  CHATTER_REDIRECT_URI -
//
// Author:
//  Aaron <amishiyev@wickr.com>

var axios = require('axios');

module.exports = (robot) => {
  robot.respond(/chatter (.*) message (.*)/i, function(res) {
    var client_id = process.env.CHATTER_CLIENT_ID;
    var client_secret = process.env.CHATTER_CLIENT_SECRET;
    var redirect_uri = process.env.CHATTER_REDIRECT_URI;
    var access_token,
      instance_url,
      refresh_token,
      token_type;
    let resScope = res;
    let user_name = res.match[1];
    let user_msg = res.match[2];

    //Check if user logged in to Saleforce already
    if (robot.brain.get('chatter_access_token') == null) {
      resScope.reply('Please login to your Saleforce account to continue: ' +
        "https://login.salesforce.com/services/oauth2/authorize?response_type=code&client_id=" + client_id + '&redirect_uri=' + redirect_uri);
    } else {
      sendMessage();
    }

    robot.router.get('/services/oauth2/callback', (req, res, next) => {
      res.send("Thanks for signing into Salesforce using Wickr. Enjoy!");
      return new Promise((resolve, reject) => {
        resolve(req);
      }).then(req => {
        return new Promise((resolve, reject) => {
          const code = req.query.code;
          console.log("code_output: " + code);
          resolve(code);
        }).then(code => {
          return new Promise((resolve, reject) => {
            var dataString = "grant_type=authorization_code&code=" + code + "&client_id=" + client_id + "&client_secret=" + client_secret + "&redirect_uri=" + redirect_uri;
            axios({
              method: 'post',
              url: 'https://login.salesforce.com/services/oauth2/token',
              data: dataString,
              headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
              }
            }).then(function(result) {
              resolve(result);
            }).catch(function(error) {
              console.log(error);
            });
          }).then(result => {
            console.log("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n")
            console.log(result.data);
            robot.brain.set('chatter_access_token', result.data.access_token); //keep secure
            robot.brain.set('chatter_instance_url', result.data.instance_url); //keep secure
            robot.brain.set('chatter_refresh_token', result.data.refresh_token);
            robot.brain.set('chatter_token_type', result.data.token_type);
            console.log("\nAccess_token: " + robot.brain.get('chatter_access_token'));
            console.log("\nInstance_url: " + robot.brain.get('chatter_instance_url'));
            console.log("\nRefresh_token: " + robot.brain.get('chatter_refresh_token'));
            sendMessage();
          }).catch(err => {
            console.log(err);
          });
        }).catch(err => {
          console.log(err);
        });
      }).catch(err => {
        console.log(err);
      });
    });


    function sendMessage() {
      return new Promise((resolve, reject) => {
        axios({
          method: 'get',
          url: robot.brain.get('chatter_instance_url') + '/services/data/v42.0/chatter/users',
          headers: {
            'Authorization': robot.brain.get('chatter_token_type') + ' ' + robot.brain.get('chatter_access_token')
          },
          json: true
        }).then(function(result) {
          resolve(result.data);
        }).catch(function(error) {
          console.log(error);
        });

      }).then(result => {
        return new Promise((resolve, reject) => {
          var user_id;
          for (var x in result.users) {
            if (result.users[x].email === user_name) {
              user_id = result.users[x].id;
              console.log("user_id: " + user_id);
            }
          }
          var dataString2 = "recipients=" + user_id + "&text=" + user_msg;
          resolve(dataString2);

        }).then(result => {
          axios({
            method: 'post',
            url: robot.brain.get('chatter_instance_url') + '/services/data/v42.0/chatter/users/me/messages',
            data: result,
            headers: {
              'Authorization': robot.brain.get('chatter_token_type') + ' ' + robot.brain.get('chatter_access_token')
            },
            json: true
          }).then(function(result) {
            console.log(result.status);
            console.log(result.statusText);
            resScope.reply("Message to " + user_name + " was sent successfully.");
          }).catch(function(error) {
            if (error.response.status == 400)
              resScope.reply("The request could not be understood, usually because the user ID is not valid for the particular resource.");
            else if (error.response.status == 401)
              resScope.reply("The session ID or OAuth token has expired or is invalid. Please sign-in again.");
            else if (error.response.status == 500)
              resScope.reply("An error has occurred within Salesforce, so the request could not be completed. Contact Salesforce Customer Support.");
            else
              resScope.reply("The request has been refused. Verify that the context user has the appropriate permissions to access the requested data, or that the context user is not an external user.");
            }
          );
        }).catch(err => {
          console.log(err);
        });
      }).catch(err => {
        console.log(err);
      });
    }
  });
}
