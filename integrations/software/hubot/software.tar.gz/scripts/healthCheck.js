module.exports = (robot) => {

  robot.router.get('/', function(req, res) {
    console.log("OK 200");
    res.send('OK 200');
  });
  }
