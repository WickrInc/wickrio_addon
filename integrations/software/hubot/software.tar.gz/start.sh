#!/bin/sh

npm start
sleep 1
npm start
