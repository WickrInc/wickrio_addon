#!/bin/sh

npm start
