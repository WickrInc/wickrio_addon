#!/bin/sh

npm install -g coffeescript pm2 coffee-script axios
npm install
