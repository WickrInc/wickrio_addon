#!/bin/sh

npm install -g coffeescript pm2 coffee-script
npm install
mv hubot-wickr node_modules
mv prompt node_modules
