#!/usr/bin/env node
'use strict';
const dotenv = require('dotenv');
const shell = require('shelljs');
const cp = require('child_process');
const spawn = require('child_process').spawn;


dotenv.config();
cp.spawn(
  process.platform === 'win32' ? 'hubot.cmd' : 'bin/hubot -a wickr',
  process.argv.slice(2),
  {stdio: 'inherit'}
);

shell.exec('bin/hubot -a wickr');
