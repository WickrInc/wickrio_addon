const fs = require('fs');

//Fill installed.txt with data from external-scripts.json
const {exec} = require('child_process');
var data = require('./external-scripts.json');
var jsonData = JSON.stringify(data, null, "\t");

return new Promise(function(resolve, reject) {
  fs.writeFile("installed.txt", jsonData, function(err) {
    if (err) {
      reject(err);
    } else {
      resolve(jsonData);
    }
  });

}).then(function() {
  //Fill installed.txt with data from the /scripts directory
  exec('ls ./scripts >> installed.txt', (err, stdout, stderr) => {
    if (err) {
      // node couldn't execute the command
      console.log(`stderr: ${err}`);
    }
  });
  //Determine which scripts are installed and edit integrations.json accordingly
  fs.readFile("./installed.txt", function(err, data) {
    if (err)
      throw err;

    var m = JSON.parse(fs.readFileSync('integrations.json').toString());
    m.forEach(function(p) {
      if (data.indexOf(p.name) >= 0) {
        p.exists = "true";
      } else {
        p.exists = "false";
      }
    });
    fs.writeFile('integrations.json', JSON.stringify(m, null, "\t"));
  });

  //Prompts the user to enter tokens for installed
  var k = JSON.parse(fs.readFileSync('integrations.json').toString());
  k.forEach(function(p) {
    if (p.exists == "true" && p.token != null) {
      p.token.forEach(function(i) {
        let data = i + "\n";
        fs.appendFile('tokens.txt', data, (err) => {
          if (err) {
            console.log(err);
          }
        });
      });
    }
  });
}).catch(function(err) {
  console.log("error here: " + err);
});
