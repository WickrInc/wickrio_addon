// Description
//  A hubot script that allows users to send messages to Wickr users from Slack.
//
// Configuration:
//   slack_token - Sender user's private slack token
//
// Commands:
//   /w send <USER.HANDLE> message <actual message>
//
// Authors:
// Aaron <amishiyev@wickr.com>
// Pak <pchu@wickr.com>

module.exports = (robot) => {

  //listening the incoming post request from slack
  robot.router.post("/slack", (req, res) => {
    //res only exist outside the robot.http block
    var outsideRes = res;

    //the incoming body object
    let messageString = req.body.text;
    //splitting the string into array
    let arrayString = messageString.split(" ");
    //get the first email from the array
    let email = arrayString[1];
    //get the message position in the messageString/req.body/text
    let messagePosition = messageString.indexOf("message");
    //slice the message out from the string
    let message = messageString.slice(messagePosition+8);
    //get the user name
    let userName = req.body.user_name;

    //parsing the message
     message = "WickrBot non-secure message from " + userName + ": " + message
      data = {
        "message": message,
        "users": [{
          "name": email
        }]
      }
      //stringify the data before making http request
      JSONData = JSON.stringify(data);

      //hubot making http request to hubot that is living on AWS ubuntu.
      var beta_server = process.env.BETA_SERVER;
      robot.http(beta_server)
        .header('Content-Type', 'application/json')
        .header('Authorization', 'Basic YWRtaW46YWRtaW4=')
        .post(JSONData)(function(err, res, body) {
          if (err) {
            outsideRes.send('Error');
          }
          outsideRes.send('Successful Send to Wickr Chat');
        });

    /* In any event you need to send message back to hubot brain you will need to import adapter class
    let Adapter,
      Robot,
      TextMessage,
      User;
    try {
      ({Robot, Adapter, TextMessage, User} = require('hubot'));
    } catch (error) {
      const prequire = require('parent-require');
      ({Robot, Adapter, TextMessage, User} = prequire('hubot'));
    }

    create a TextMessage class and sends it back up
    */
    // robot.receive(message);
    // robot.logger.info("Message sent to hubot brain.");
  });
}
