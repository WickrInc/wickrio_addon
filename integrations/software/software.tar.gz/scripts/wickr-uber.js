// Description
//   A hubot script that allows users to order and get ride information from Uber using Wickr.
//
// Commands:
//   uber price <location> to <destination> - Cost and Duration of ride from <location> to <destination>
//   uber time - Time an Uber car will take to get to your current location
//   uber ride <location> to <destination> - Requests a ride from <location> to <destination>.
//   uber current - Current ride Information
//   uber cancel - Cancel current ride
//
// Authors:
//   Pak <pchu@wickr.com>
//   Aaron <amishiyev@wickr.com>

var Uber = require('node-uber');
var request = require("request");

var uber = new Uber({
  client_id: process.env.CLIENT_ID,
  client_secret: process.env.CLIENT_SECRET,
  server_token: process.env.SERVER_TOKEN,
  redirect_uri: process.env.REDIRECT_URI,
  name: process.env.NAME,
  language: 'en_US', // optional, defaults to en_US
  sandbox: true // optional, defaults to false
});

module.exports = (robot) => {
  let client_id = process.env.CLIENT_ID;
  let client_secret = process.env.CLIENT_SECRET;
  let server_token = process.env.SERVER_TOKEN;
  let access_code;
  let latsLngsParams;

  robot.hear(/uber price (.*) to (.*)/i, function(res) {
    let from = res.match[1].replace(/ /g, "+");
    let to = res.match[2].replace(/ /g, "+");
    let resScope = res;

    robot.http('https://maps.googleapis.com/maps/api/geocode/json?address=' + from + '&key=AIzaSyBQULp7Y6W9x0Wnq_dBRQsLnY7L52dJ81U').post()(function(err, response, body) {
      let data = JSON.parse(body);
      let latFrom = data.results[0].geometry.location.lat;
      let lngFrom = data.results[0].geometry.location.lng;

      robot.http('https://maps.googleapis.com/maps/api/geocode/json?address=' + to + '&key=AIzaSyBQULp7Y6W9x0Wnq_dBRQsLnY7L52dJ81U').post()(function(err, response, body) {
        let data = JSON.parse(body);
        let latTo = data.results[0].geometry.location.lat;
        let lngTo = data.results[0].geometry.location.lng;

        robot.http('https://api.uber.com/v1.2/estimates/price?start_latitude=' + latFrom + '&start_longitude=' + lngFrom + '&end_latitude=' + latTo + '&end_longitude=' + lngTo)
          .header('Authorization', 'Token ' + server_token)
          .header('Content-Type', 'application/json')
          .get()(function(err, response, body) {
            let data = JSON.parse(body);
            for (x in data.prices) {
              resScope.reply('Product: ' + data.prices[x].localized_display_name + ', Price Estimate: ' + data.prices[x].estimate +
                ', Duration: ' + (data.prices[x].duration) / 60 + ' minutes.');
            }
          });
      });
    });
  });

  robot.hear(/uber time/i, function(res) {

    let resScope = res;

    robot.http('https://www.googleapis.com/geolocation/v1/geolocate?key=AIzaSyDlGzMZRkXx2c51zOcc6xgX3OXLEpK0jHo').post()(function(err, response, body) {
      let data = JSON.parse(body);
      let latFrom = data.location.lat;
      let lngFrom = data.location.lng;
      robot.http('https://api.uber.com/v1.2/estimates/time?start_latitude=' + latFrom + '&start_longitude=' + lngFrom)
        .header('Authorization', 'Token ' + server_token)
        .header('Content-Type', 'application/json')
        .get()(function(err, response, body) {
          let data = JSON.parse(body);
          for (x in data.times) {
            resScope.reply(
              'Product: ' + data.times[x].localized_display_name + ', Time Estimate: ' + (data.times[x].estimate) / 60 + ' minutes.');
          }
        });
    });
  });


  robot.hear(/uber ride (.*) to (.*)/i, (res) => {
    let resScope = res;

    let from = res.match[1].replace(/ /g, "+");
    let to = res.match[2].replace(/ /g, "+");

    robot.http('https://maps.googleapis.com/maps/api/geocode/json?address=' + from + '&key=AIzaSyBQULp7Y6W9x0Wnq_dBRQsLnY7L52dJ81U').post()(function(err, response, body) {
      let data = JSON.parse(body);
      let latFrom = data.results[0].geometry.location.lat;
      let lngFrom = data.results[0].geometry.location.lng;

      robot.http('https://maps.googleapis.com/maps/api/geocode/json?address=' + to + '&key=AIzaSyBQULp7Y6W9x0Wnq_dBRQsLnY7L52dJ81U').post()(function(err, response, body) {
        let data = JSON.parse(body);
        let latTo = data.results[0].geometry.location.lat;
        let lngTo = data.results[0].geometry.location.lng;

        resScope.reply('Please login to your Uber account to continue: https://login.uber.com/oauth/v2/authorize?client_id=' + client_id + '&response_type=code');

        robot.router.get('/authenticate', (req, res, next) => {
          return new Promise((resolve, reject) => {
              resolve(req);
            })
            .then(result => {
              return new Promise((resolve, reject) => {
                authorization_code = result.query.code;
                //robot.brain.set('authorization_code', authorization_code);
                resolve(authorization_code)
                res.redirect('https://uber-thank-you.herokuapp.com/');
              })
            })
            .then(authorization_code => {
              return new Promise((resolve, reject) => {
                uber.authorizationAsync({
                    authorization_code: authorization_code
                  })
                  .spread((access_token, refresh_token, authorizedScopes, tokenExpiration) => {
                    // store the user id and associated access_token, refresh_token, scopes and token expiration date
                    // console.log('New access_token retrieved: ' + access_token);
                    // console.log('... token allows access to scopes: ' + authorizedScopes);
                    // console.log('... token is valid until: ' + tokenExpiration);
                    // console.log('... after token expiration, re-authorize using refresh_token: ' + refresh_token);

                    resolve(access_token);
                  })
                  .error(function(err) {
                    console.log(err);
                  });
              })
            })
            .then(access_token => {
              return new Promise((resolve, reject) => {
                robot.brain.set('access_token', access_token);
                latsLngsParams = JSON.stringify({
                  'start_latitude': latFrom,
                  'start_longitude': lngFrom,
                  'end_latitude': latTo,
                  'end_longitude': lngTo
                })

                robot.http('https://sandbox-api.uber.com/v1.2/requests/estimate')
                  .header("Authorization", "Bearer " + access_token)
                  .header("Content-Type", "application/json")
                  .post(latsLngsParams)((err, response, body) => {
                    resolve(body);
                    let data = JSON.parse(body);
                    //console.log(body);
                    let price = JSON.stringify(data.fare.display);
                    let duration = JSON.stringify(data.trip.duration_estimate);

                    let paramRequest_start_lat_start_lng_end_lat_end_lng = JSON.stringify({
                      'start_latitude': latFrom,
                      'start_longitude': lngFrom,
                      'end_latitude': latTo,
                      'end_longitude': lngTo,
                      'fare_id': data.fare.fare_id
                    })
                    resScope.reply('The requested ride is gonna cost ' + price + ', and would take about ' + duration / 60 + ' minutes. ' +
                      'Do you wish to proceed? (yes/no)');
                    robot.hear(/yes/i, function(res) {
                      robot.http('https://sandbox-api.uber.com/v1.2/requests')
                        .header("Authorization", "Bearer " + access_token)
                        .header("Accept-Language", "en_US")
                        .header("Content-Type", "application/json")
                        .post(paramRequest_start_lat_start_lng_end_lat_end_lng)(function(err, response, body) {
                          let data = JSON.parse(body);
                          let status = JSON.stringify(data.status);
                          let request_id = JSON.stringify(data.request_id);
                          resolve(data);
                          resScope.reply("Great! your ride has been ordered.");
                        });
                    });

                  });
              })
            })
            .catch(e => {
              console.log('Error: ', e);
            })
        });
      });
    });
  });

  robot.hear(/uber current/i, function(res) {

    let resScope = res;

    robot.http('https://sandbox-api.uber.com/v1.2/requests/current')
      .header("Authorization", "Bearer " + robot.brain.get('access_token'))
      .header("Accept-Language", "en_US")
      .header("Content-Type", "application/json")
      .get()(function(err, response, body) {
        let data = JSON.parse(body);
        var request_id;
        if (!data.status){
          resScope.reply("There is no current trip.");
        }
        else{
        request_id = JSON.stringify(data.request_id);
        var mapURL;
        robot.http('https://sandbox-api.uber.com/v1.2/requests/' + data.request_id + '/map')
          .header("Authorization", "Bearer " + robot.brain.get('access_token'))
          .header("Accept-Language", "en_US")
          .header("Content-Type", "application/json")
          .get()((err, response, body) => {
            return new Promise((resolve, reject) => {
                resolve(body);
              })
              .then(result => {
            if(!body.href){
              mapURL = "A map is not available for this trip.";
            }
            else{
            mapURL = body.href;
          }
        let pickup = data.pickup.region.name;
        let eta = data.pickup.eta;
        let status = data.status;

        resScope.reply("Ride status: " + status + "\nPick-Up Location: " + pickup +
         "\nETA: " + eta + " minutes"+ "\nRide Map: " + mapURL);

         //Uncomment before deploying the script
         //let carMake = JSON.stringify(data.vehicle.make);
         //let carModel = JSON.stringify(data.vehicle.model);
        //res.reply("Driver vehicle: " + carMake + " " + carModel);
      })
      .catch(e => {
        console.log('Error: ', e);
      });
    });
        }
      });
  });


  robot.hear(/uber cancel/i, function(res) {
    var resScope = res;
    const options = {
      url: 'https://sandbox-api.uber.com/v1.2/requests/current',
      method: 'DELETE',
      headers: {
        'Authorization': "Bearer " + robot.brain.get('access_token'),
        'Accept-Language': 'en_US',
        'Content-Type': 'application/json'
      }
    };
    request(options, function(err, res, body) {
      if (res.statusCode == 204)
        resScope.reply("Ride cancelled.");
      else if (res.statusCode == 404)
        resScope.reply("There is no scheduled trip.");
      else
        resScope.reply("Error: Forbidden.");
    });
  });
}
