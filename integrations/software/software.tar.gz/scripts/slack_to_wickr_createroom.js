// Description
//  A hubot script that allows users to create a Wickr room from Slack.
//
// Configuration:
//
//
// Command:
//   /createroom <RoomName> with <user1>, <user2>
//
// Notes:
//   user1 should always equal to the requesting user's Wickr ID which will also be the room's admin.
//
// Authors:
// Aaron <amishiyev@wickr.com>
// Pak <pchu@wickr.com>

var axios = require('axios');
var request = require('request');

module.exports = (robot) => {

  robot.router.post("/createroom", (req, res) => {

    var outsideRes = res;
    var index = req.body.text.indexOf("with");

    var roomName = req.body.text.slice(0, index - 1);
    var users = req.body.text.slice(index + 4);
    var arr = [];

    users = users.split(',');
    for (var i = 0; i < users.length; i++) {
      arr.push(users[i].trim(""));
    }

    var membersArr = [];
    for (var i = 0; i < arr.length; i++) {
      var temp = {};
      temp['name'] = arr[i];
      membersArr.push(temp);
    }

    let data = {
      "room": {
        "title": roomName,
        "description": "Slack-created room by: " + membersArr[0].name,
        "ttl": 0,
        "members": membersArr,
        "masters": [{
          "name": membersArr[0].name
        }]
      }
    }

    const options = {
      headers: {
        'Authorization': "Basic YWRtaW46YWRtaW4=",
        'Content-Type': 'application/json'
      }
    };

    var beta_server = process.env.BETA_SERVER;
    function createRoom(roomData, auth) {
      return axios.post("http://localhost:4001/Apps/1001/Rooms", roomData, auth)
        .then(function(parsedData) {
          console.log('parsedData ',parsedData.data.vgroupid);
          outsideRes.send('Successful Room creation in Wickr Chat');
          return parsedData.data.vgroupid;
        })
        .then(function(result) {
          console.log('70', result);

          data = {
            "message": "Enjoy your secured room, and have a nice day! Wickrbot OUT!",
            "vgroupid": result
          }

          JSONData = JSON.stringify(data);
          console.log("JSONData: "+JSONData);
          robot.http(beta_server)
            .header('Content-Type', 'application/json')
            .header('Authorization', 'Basic YWRtaW46YWRtaW4=')
            .post(JSONData)(function(err, res, body) {
              if (err) {
                console.log(err);
                outsideRes.send('Error: '+ err);
                return;
              }
              console.log('88 body', body);
            });
          return result
        })
        .then(function(result) {
          console.log('94', result);

          const options = {
            url: 'http://localhost:4001/Apps/1001/Rooms/'+ result +'?reason=leave',
            method: 'DELETE',
            headers: {
              'Authorization': "Basic YWRtaW46YWRtaW4=",
              'Content-Type': 'application/json'
            }
          };

          setTimeout(function() {
            request(options, function(err, res, body) {
              if (err) {
                console.log(err);
                outsideRes.send('Error: '+ err);
                return;
              }
              console.log('REQUEST');
            })
          }, 1000)

        })
        .catch(function(errData){
          console.log('Err ', errData);
          outsideRes.send('Err', errData);
          return errData
        });
    }

    createRoom(data, options);


  });
}





/*

return new Promise((resolve, reject) => {
    resolve(body);
  })
  .then(result => {
    return new Promise((resolve, reject) => {
      resolve(result)
      console.log(result);
      let  vgroupidVar = JSON.parse(result);

      data = {
        "message": "Enjoy your secured room, and have a nice day! Wickrbot OUT!",
        "vgroupid": vgroupidVar
      }

      JSONData = JSON.stringify(data);
      console.log("JSONData: "+JSONData);
      this.robot.http("http://localhost:4002/Apps/1002/messages")
        .header('Content-Type', 'application/json')
        .header('Authorization', 'Basic YWRtaW46YWRtaW4=')
        .post(JSONData)(function(err, res, body) {
          if (err) {
            console.log(err);
          }
          console.log(body);
        });

    })
  })
=====
var vgroupidVar = vgroupID.vgroupid;
const options = {
  url: 'http://localhost:4002/Apps/1002/Rooms/'+ vgroupidVar +'?reason=leave',
  method: 'DELETE',
  headers: {
    'Authorization': "Basic YWRtaW46YWRtaW4=",
    'Content-Type': 'application/json'
  }
};

  request(options, function(err, res, body) {
    if (err) {
      console.log(err);
      outsideRes.send('Error: '+ err);
      return;
    }
    console.log('REQUEST');
  })

=====

.then(result => {
  console.log('99', result);
  var vgroupidVar = result.vgroupid;

  const options = {
    url: 'http://localhost:4002/Apps/1002/Rooms/'+ vgroupidVar +'?reason=leave',
    method: 'DELETE',
    headers: {
      'Authorization': "Basic YWRtaW46YWRtaW4=",
      'Content-Type': 'application/json'
    }
  };

  request(options, function(err, res, body) {
    if (err) {
      console.log(err);
      outsideRes.send('Error: '+ err);
      return;
    }
    console.log('REQUEST');
  })
})
.catch(e => {
  console.log('err', e);
})

=====

robot.http("http://localhost:4002/Apps/1002/Rooms")
  .header('Content-Type', 'application/json')
  .header('Authorization', 'Basic YWRtaW46YWRtaW4=')
  .post(JSONData)(function(err, res, body) {
   new Promise( (resolve, reject) => {
      if (err) {
        //console.log('Err', err);
        outsideRes.send('Err', err);
        reject(err);
        return;
      }
      resolve(body);
      outsideRes.send('Successful Room creation in Wickr Chat');
      return;
    })
    .then(result => {
      let vgroupIDObject = JSON.parse(result)
      let vgroupid = vgroupIDObject.vgroupid;

      vgroupIDGlobal = vgroupid

      data = {
        "message": "Enjoy your secured room, and have a nice day! Wickrbot OUT!",
        "vgroupid": vgroupid
      }

      let JSONData = JSON.stringify(data);

      robot.http("http://localhost:4002/Apps/1002/messages")
        .header('Content-Type', 'application/json')
        .header('Authorization', 'Basic YWRtaW46YWRtaW4=')
        .post(JSONData)(function(err, res, body) {
      let data = new Promise((resolve, reject) => {
            if (err) {
              console.log(err);
              outsideRes.send('Err', err);
              reject(err)
              return;
            }
            resolve(vgroupid)
            outsideRes.send('Hubot Out!');
            return;
          })


        })
    })
    .catch(e => {
      console.log('Error catch', e);
    })
  })

=====
let JSONData = JSON.stringify(data);

const options = {
  method: 'POST',
  uri: "http://localhost:4002/Apps/1002/Rooms",
  headers: {
    'Authorization': "Basic YWRtaW46YWRtaW4=",
    'Content-Type': 'application/json'
  },
  json: data
};

requestPromise(options)
  .then(function (parsedBody) {
    console.log('parsedBody ', parsedBody);
    outsideRes.send('Successful Room creation in Wickr Chat');
  })
  .catch(function (err) {
    console.log('Err ', err);
    outsideRes.send('Err', err);
});

  */
