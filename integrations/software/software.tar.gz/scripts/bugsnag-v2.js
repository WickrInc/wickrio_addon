// Description
//   A hubot script that utilizes the Bugsnag Data access API Version 2.
//
// Configuration:
//   LIST_OF_ENV_VARS_TO_SET
//
// Commands:
//  None
//
// Notes:
//   <optional notes required for the script>
//
// Author:
//   Aaron <amishiyev@wickr.com>

module.exports = (robot) => {

  var resVar;

  robot.router.post("/bugsnag", (req, res) => {
    //let data = JSON.parse(res);
    //console.log(res);

    robot.messageRoom("/apps/1002","Error: "+ req.body.error.message + '\n' + "Severity: " + req.body.error.severity + ". URL: " + req.body.error.url);
});
};
