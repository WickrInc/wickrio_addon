// Description
//  A hubot script that allows users to send messages to Slack users from Wickr.
//
// Configuration:
//   slack_token - Sender user's private slack token
//
// Commands:
//   wkrbot send <USER.HANDLE> message <actual message>
//
//
// Authors:
// Aaron <amishiyev@wickr.com>
// Pak <pchu@wickr.com>

module.exports = (robot) => {
  var slack_token = process.env.SLACK_TOKEN;

  //command to trigger the script
  robot.hear(/send (.*) message (.*)/i, function(res) {
    let userEmail = res.match[1];
    let msg = res.match[2];

    var userID = '';
    //making http request to find the specified user's ID from list of all users existing in the sender's workspace
    this.robot.http("https://slack.com/api/users.list").header('Content-Type', 'application/json')
    .header('Authorization', 'Bearer ' + slack_token)
    .post()(function(err, res, body) {
      return new Promise((resolve, reject) => {
        if (err) {
          reject(err);
          return;
        }
        let list = JSON.parse(body);
        for (var x = 0; x < list.members.length; x++) {
          if (list.members[x].name === userEmail){
            userID = list.members[x].id;
            resolve(userID);
            break;}
          }
          if(userID === ''){
            console.log("HIT");
              let data2 = {
                "message": "User Not Found!",
                "users": [{
                  "name": "wickraaron@wickrautomation.com"
                }]
              }
              let JSONData2 = JSON.stringify(data2);
              var beta_server = process.env.BETA_SERVER;
              robot.http(beta_server)
                .header('Content-Type', 'application/json')
                .header('Authorization', 'Basic YWRtaW46YWRtaW4=')
                .post(JSONData2)(function(err, res, body) {
                  if (err) {
                    console.log(err);
                  }
                });
          }
      })
      .then(result => {
        userID = result;
        msg = "WickrBot non-secure message: " + msg;
        let data = {
          "channel": userID,
          "text": msg,
          "username": userEmail,
          "as_user": "true"
        }
        JSONData = JSON.stringify(data);
        //http request to post the message in the slack Chat/DM
        robot.http("https://slack.com/api/chat.postMessage")
        .header('Content-Type', 'application/json')
        .header('Authorization', 'Bearer ' + slack_token)
        .post(JSONData)(function(err, res, body) {
          let response = JSON.parse(body);
          console.log(response);
          if (err) {
            console.log(err);
          }
          else if(response.ok === false){
            console.log("HIT");
              let data3 = {
                "message": "Error cannot send message: " + response.error,
                "users": [{
                  "name": "wickraaron@wickrautomation.com"
                }]
              }
              let JSONData3 = JSON.stringify(data3);
              robot.http(beta_server)
                .header('Content-Type', 'application/json')
                .header('Authorization', 'Basic YWRtaW46YWRtaW4=')
                .post(JSONData3)(function(err, res, body) {
                  if (err) {
                    console.log(err);
                  }
                });
          }

        });
      })
      .catch(error => {
        console.log(error);
      })
      })

    });

}
