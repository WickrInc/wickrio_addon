const fs = require('fs');
const path = require('path');

const externalScripts = require('./external-scripts.json');
const jsonExternalScripts = JSON.stringify(externalScripts);

const fileName = 'installed.txt';
const folderPath = path.join(__dirname, 'scripts');

const {exec} = require('child_process');

var shell = require('shelljs');

async function writeFile(){
  let file = await new Promise(function(resolve, reject) {
    fs.writeFile(fileName, jsonExternalScripts, (err) => {
      if (err) {
        reject(err)
      }
      resolve(jsonExternalScripts)
    });
  });
  return file;
}

writeFile();

async function readFile() {
  let file = await new Promise(function(resolve, reject) {
    fs.readdir(folderPath, (err, file) => {
      if (err) {
        console.log(err);
        reject(err);
      }
      //console.log('SUCCESS!');
      resolve(file);
    });
  });
  return file;
}

readFile()
  .then(result => {
    let resultArray = [];
    for(let i = 0; i < result.length; i++) {
      resultArray.push(result[i]);
    }

    fs.readFile(fileName, 'utf8', (err, data) => {
      if (err) {
        console.log(err);
      }
      let dataParsed = JSON.parse(data);
      for(let i = 0; i < resultArray.length; i++) {
        dataParsed.push(resultArray[i]);
      }
      let finalParsedJSON = JSON.stringify(dataParsed, null, "\t");
      fs.writeFile(fileName, finalParsedJSON, 'utf8', (err) => {
        if (err) {
          console.log(err);
        }
        //console.log('SUCCESS');
        readFileJSON().then(result => {
          //console.log(result);
          getIntegrationArray(result)
            .then(result => {
              checkIntegration(result)
                .then(result => {
                  console.log(result, '123');
                  shell.exec('ls -l');
                })
            })
        })
        .catch(err => {
          console.log(err);
        })
      });
    })
  });

async function readFileJSON() {
  let file = await new Promise(function(resolve, reject) {
    fs.readFile(fileName, 'utf8',(err, file) => {
      if (err) {
        console.log(err);
        reject(err);
      }
      //console.log('SUCCESS!');
      resolve(file);
    });
  });
  return file;
}

function getIntegrationArray(targetData) {
  return new Promise((resolve, reject ) => {
    var integrationsJSON = JSON.parse(fs.readFileSync('integrations.json').toString());
      integrationsJSON.forEach(function(p) {
      if (targetData.indexOf(p.name) >= 0) {
        p.exists = "true";
      } else {
        p.exists = "false";
      }
    });
    fs.writeFile('integrations.json', JSON.stringify(integrationsJSON, null, "\t"), (err) => {
      if (err) {
        reject(err)
      }
      //console.log('SUCCESS');
       var newIntegrationsJSON = JSON.parse(fs.readFileSync('integrations.json').toString());
       //console.log(newIntegrationsJSON);
       console.log("Please enter your credentials for the following configuration values(e.g. 'export PORT=1000'): ");
       resolve(newIntegrationsJSON);
    });
  })
}

function checkIntegration(integrationsArray) {
  return new Promise((resolve, reject) => {
    integrationsArray.forEach(function(p) {
     if (p.exists == "true" && p.token != null) {
         fs.writeFile('tokens.txt', "", (err) => {
           //console.log('Success');
         });
       p.token.forEach((i, index) => {
         let data = i + "\n"
         fs.appendFile('tokens.txt', data, (err) => {
           if (err) {
             console.log(err);
             reject(err)
           }
           //console.log('SUCCESS');
           resolve('SUCCESS')
         });
       });
     }
   });
  })
}
