#!/bin/sh

mkdir files
npm install
