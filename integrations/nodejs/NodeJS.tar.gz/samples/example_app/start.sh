#!/bin/sh
npm start
