#!/bin/sh

npm install
