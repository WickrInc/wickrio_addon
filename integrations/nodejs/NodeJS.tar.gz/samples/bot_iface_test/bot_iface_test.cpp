#include <iostream>
#include "src/bot_iface.h"
using namespace std;

inr main(){

cout << "6+7 .cpp:" << add(6,7) << endl;
}
